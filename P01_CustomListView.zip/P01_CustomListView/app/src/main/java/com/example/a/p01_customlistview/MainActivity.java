package com.example.a.p01_customlistview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<MyData> list = new ArrayList<>();

        MyData data1 = new MyData("test1","test11",R.mipmap.menu_img_1);
        list.add(data1);
        MyData data2 = new MyData("test2","test12",R.mipmap.menu_img_2);
        list.add(data2);
        MyData data3 = new MyData("test3","test13",R.mipmap.menu_img_3);
        list.add(data3);
        MyData data4 = new MyData("test4","test14",R.mipmap.menu_img_4);
        list.add(data4);
        MyData data5 = new MyData("test5","test15",R.mipmap.menu_img_5);
        list.add(data5);


        ListView listView = (ListView) findViewById(R.id.listView);

        MyAdapter adapter = new MyAdapter(MainActivity.this,android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);

    }
}
