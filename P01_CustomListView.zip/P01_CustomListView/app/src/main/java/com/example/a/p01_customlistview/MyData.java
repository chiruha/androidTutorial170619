package com.example.a.p01_customlistview;

/**
 * Created by a on 2017-06-20.
 */

class MyData{
    String title;
    String desc;
    int imgIcon;

    public MyData(String title, String desc, int imgIcon) {
        this.title = title;
        this.desc = desc;
        this.imgIcon = imgIcon;
    }
}
